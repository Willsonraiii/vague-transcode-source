@echo off
REM  Same as vague.bat but ALSO applies the experimental duration patch.
REM  Output will show 0:00 in players - that is expected.
setlocal
cd /d "%~dp0"
if "%~1"=="" ( echo Drag a video onto this file. & pause & exit /b )
echo.
node "%~dp0vague.js" "%~1" --platform tiktok --patch
echo.
pause
