@echo off
REM  Lossless container fix only - no re-encode, nothing touched.
REM  Use this for a master that is already the right size/codec.
setlocal
cd /d "%~dp0"
if "%~1"=="" ( echo Drag a video onto this file. & pause & exit /b )
echo.
node "%~dp0vague.js" "%~1" --remux-only
echo.
pause
