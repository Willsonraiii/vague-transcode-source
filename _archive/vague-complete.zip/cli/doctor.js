#!/usr/bin/env node
/**
 * Vague Doctor — preflight check.
 *
 * Finds out in ~30 seconds whether your machine can actually do the job,
 * instead of discovering it after a 10 minute encode fails.
 *
 * The important test is #5: it runs a real 1-frame x265 encode with the
 * Dolby Vision parameters. Many ffmpeg builds ship an x265 without DV
 * support, and that is the single most common reason this pipeline fails.
 */

'use strict';
const { spawnSync } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

const C = { r:'\x1b[31m', g:'\x1b[32m', y:'\x1b[33m', b:'\x1b[36m', d:'\x1b[2m', x:'\x1b[0m', B:'\x1b[1m' };
const WIN = process.platform === 'win32';
const FFMPEG_FIX = WIN
  ? 'winget install Gyan.FFmpeg   — then open a NEW terminal'
  : 'Debian/Ubuntu: sudo apt install ffmpeg   |   Fedora: sudo dnf install ffmpeg   |   Arch: sudo pacman -S ffmpeg';
const FULLBUILD_FIX = WIN
  ? 'Get ffmpeg-release-FULL from gyan.dev (not "essentials")'
  : 'Distro ffmpeg often lacks DV. Use a static build: https://johnvansickle.com/ffmpeg/ or https://github.com/BtbN/FFmpeg-Builds/releases';
const DOVI_FIX = WIN
  ? 'https://github.com/quietvoid/dovi_tool/releases → put dovi_tool.exe next to ffmpeg.exe'
  : 'https://github.com/quietvoid/dovi_tool/releases → download the x86_64-unknown-linux-musl tarball, then: sudo install dovi_tool /usr/local/bin/';
const say = (...a) => console.log(...a);
let fatal = 0, warn = 0;

const PASS = (l, extra='') => say(`  ${C.g}✓${C.x} ${l}${extra ? C.d+'  '+extra+C.x : ''}`);
const WARN = (l, fix)      => { warn++;  say(`  ${C.y}!${C.x} ${l}`); if (fix) say(`      ${C.d}${fix}${C.x}`); };
const FAIL = (l, fix)      => { fatal++; say(`  ${C.r}✗${C.x} ${l}`); if (fix) say(`      ${C.y}${fix}${C.x}`); };

function run(bin, args, timeout = 25000) {
  return spawnSync(bin, args, { encoding:'utf8', timeout, maxBuffer: 1<<26 });
}
function exists(bin, verArgs = ['-version']) {
  const r = run(bin, verArgs, 8000);
  if (r.error) return null;
  return ((r.stdout || '') + (r.stderr || '')).split('\n')[0].trim();
}

say(`\n${C.B}Vague Doctor${C.x}\n${'═'.repeat(58)}`);

/* 1 ─ node ---------------------------------------------------------------- */
say(`\n${C.B}1. Node.js${C.x}`);
const nv = process.versions.node;
if (+nv.split('.')[0] >= 16) PASS(`node ${nv}`);
else FAIL(`node ${nv} is too old`, 'Install Node 18+ from https://nodejs.org');

/* 2 ─ ffmpeg / ffprobe ---------------------------------------------------- */
say(`\n${C.B}2. ffmpeg${C.x}`);
const ff = exists('ffmpeg');
const fp = exists('ffprobe');
if (ff) PASS('ffmpeg found', ff.replace('ffmpeg version ','').slice(0, 40));
else FAIL('ffmpeg NOT on PATH', FFMPEG_FIX);
if (fp) PASS('ffprobe found');
else FAIL('ffprobe NOT on PATH', 'It ships with ffmpeg — check your PATH');

/* 3 ─ libx265 ------------------------------------------------------------- */
say(`\n${C.B}3. HEVC encoder${C.x}`);
let hasX265 = false;
if (ff) {
  const enc = run('ffmpeg', ['-hide_banner','-encoders']).stdout || '';
  hasX265 = /\blibx265\b/.test(enc);
  if (hasX265) {
    const ver = (run('ffmpeg', ['-hide_banner','-h','encoder=libx265']).stdout || '')
      .match(/x265\s+([\d.]+)/);
    PASS('libx265 present', ver ? 'x265 ' + ver[1] : '');
  }
  else FAIL('libx265 MISSING — cannot encode HDR at all', FULLBUILD_FIX);

  if (/hevc_nvenc/.test(enc)) PASS('hevc_nvenc present', '(GPU available for SDR speed)');
  else say(`  ${C.d}·  hevc_nvenc not present (fine — CPU encoding still works)${C.x}`);
}

/* 4 ─ dovi_tool ----------------------------------------------------------- */
say(`\n${C.B}4. dovi_tool${C.x}`);
const dv = exists('dovi_tool', ['--version']);
if (dv) PASS('dovi_tool found', dv.slice(0, 40));
else WARN('dovi_tool NOT on PATH — Dolby Vision will be dropped (HLG base survives)', DOVI_FIX);

/* 5 ─ THE IMPORTANT ONE: does x265 accept Dolby Vision params? ------------ */
say(`\n${C.B}5. Dolby Vision encode capability  ${C.d}(the one that usually fails)${C.x}`);
if (!ff || !hasX265) {
  say(`  ${C.d}skipped — needs ffmpeg with libx265${C.x}`);
} else {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'vaguedoc-'));
  const out = path.join(tmp, 't.mp4');
  const r = run('ffmpeg', ['-hide_banner','-y',
    '-f','lavfi','-i','testsrc2=size=256x256:rate=30:duration=0.2',
    '-c:v','libx265','-preset','ultrafast','-profile:v','main10','-pix_fmt','yuv420p10le',
    '-x265-params','hdr-opt=1:repeat-headers=1:dolby-vision-profile=8.4:colorprim=bt2020:transfer=smpte2084:colormatrix=bt2020nc',
    out], 40000);
  const blob = ((r.stdout||'') + (r.stderr||''));
  const unknown = /unknown option|invalid option|not supported|Unknown x265|no member named/i.test(blob);
  const built   = fs.existsSync(out) && fs.statSync(out).size > 0;

  if (built && !unknown) {
    PASS('x265 accepted dolby-vision-profile=8.4', 'full DV pipeline should work');
  } else if (built && unknown) {
    WARN('x265 ignored the Dolby Vision options',
      'Encode will succeed but DV metadata will NOT be written. ' + FULLBUILD_FIX);
  } else {
    FAIL('x265 rejected the Dolby Vision encode', 'Your build lacks DV support. ' + FULLBUILD_FIX);
    const line = blob.split('\n').filter(l => /error|unknown|invalid/i.test(l)).slice(-2).join('\n      ');
    if (line) say(`      ${C.d}${line}${C.x}`);
  }
  fs.rmSync(tmp, { recursive:true, force:true });
}

/* 6 ─ 10-bit + HLG tagging ------------------------------------------------ */
say(`\n${C.B}6. HLG / 10-bit tagging${C.x}`);
if (ff && hasX265) {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'vaguedoc2-'));
  const out = path.join(tmp, 'h.mp4');
  run('ffmpeg', ['-hide_banner','-y','-f','lavfi',
    '-i','testsrc2=size=256x256:rate=30:duration=0.2',
    '-c:v','libx265','-preset','ultrafast','-profile:v','main10','-pix_fmt','yuv420p10le',
    '-colorspace','bt2020nc','-color_primaries','bt2020','-color_trc','arib-std-b67',
    '-tag:v','hvc1', out], 40000);
  if (fs.existsSync(out) && fp) {
    const j = run('ffprobe', ['-v','quiet','-print_format','json','-show_streams', out]).stdout;
    try {
      const s = JSON.parse(j).streams[0];
      const ok = s.color_trc === 'arib-std-b67' && /10/.test(String(s.bits_per_raw_sample || s.pix_fmt));
      ok ? PASS('HLG + 10-bit written and read back correctly')
         : WARN(`tags came back as trc=${s.color_trc} pix=${s.pix_fmt}`, 'HDR tagging may not survive');
    } catch { WARN('could not parse ffprobe output'); }
  } else WARN('test encode did not produce a file');
  fs.rmSync(tmp, { recursive:true, force:true });
} else say(`  ${C.d}skipped${C.x}`);

/* summary ----------------------------------------------------------------- */
say(`\n${'═'.repeat(58)}`);
if (fatal) {
  say(`${C.r}${C.B}  ${fatal} blocking problem${fatal>1?'s':''}${warn?` and ${warn} warning${warn>1?'s':''}`:''}.${C.x}`);
  say(`${C.d}  Fix the ✗ items above, then run this again.${C.x}\n`);
  process.exit(1);
} else if (warn) {
  say(`${C.y}${C.B}  Usable, with ${warn} warning${warn>1?'s':''}.${C.x}`);
  say(`${C.d}  You can encode now; the warnings limit what is preserved.${C.x}\n`);
} else {
  say(`${C.g}${C.B}  All good. Full pipeline available, Dolby Vision included.${C.x}`);
  say(`${C.d}  Next: ${WIN ? 'double-click Vague.bat' : './vague-app.sh'} and scan your master.${C.x}\n`);
}
