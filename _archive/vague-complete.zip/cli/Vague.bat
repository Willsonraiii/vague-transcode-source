@echo off
title Vague
cd /d "%~dp0"
echo.
echo   Starting Vague...
echo   A browser window will open. Keep this window open while using it.
echo.
node "%~dp0app.js"
pause
