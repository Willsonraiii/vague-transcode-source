#!/usr/bin/env node
/**
 * Vague CLI — local transcoder for TikTok / Instagram uploads.
 *
 * Does the things a browser cannot:
 *   • downscale 4K → 1080p while PRESERVING Dolby Vision (dovi_tool RPU carry)
 *   • preserve HLG / HDR10 with correct tagging
 *   • force CFR at the source's exact frame rate (kills the 60→30 problem)
 *   • high-quality Lanczos scaling instead of the platform's fast downscaler
 *   • verify the output before handing it to you
 *
 * Usage:
 *   node vague.js <input> [options]
 *
 *   --platform tiktok|ig_reels|ig_story|yt_shorts   (default tiktok)
 *   --out <file>        output path
 *   --keep-4k           don't downscale (default is downscale to 1080p)
 *   --sdr               force SDR tonemap even if HDR is possible
 *   --patch             zero header duration (the RTXFury trick)
 *   --remux-only        lossless container fix, no re-encode
 *   --dry-run           print the commands, run nothing
 *   --yes               skip prompts
 */

'use strict';

const { spawn, spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { plan } = require('../core/profiles');
const { diagnose, identifyToolchain } = require('../core/hdr-doctor');

/* ------------------------------------------------------------------- args */

const argv = process.argv.slice(2);
if (!argv.length || argv.includes('-h') || argv.includes('--help')) {
  console.log(fs.readFileSync(__filename, 'utf8').split('*/')[0].split('/**')[1]
    .replace(/^ \* ?/gm, '  '));
  process.exit(0);
}

const flag = n => argv.includes(`--${n}`);
const opt  = (n, d) => { const i = argv.indexOf(`--${n}`); return i >= 0 ? argv[i + 1] : d; };

const input     = argv[0];
const platform  = opt('platform', 'tiktok');
const DRY       = flag('dry-run');
const KEEP4K    = flag('keep-4k');
const FORCE_SDR = flag('sdr');
const PATCH     = flag('patch');
const REMUX     = flag('remux-only');

if (!fs.existsSync(input) && !DRY) { fail(`Input not found: ${input}`); }

const outPath = opt('out',
  path.join(path.dirname(input), path.basename(input, path.extname(input)) + '-vague.mp4'));

/* ------------------------------------------------------------------ utils */

const C = { r:'\x1b[31m', g:'\x1b[32m', y:'\x1b[33m', b:'\x1b[36m', d:'\x1b[2m', x:'\x1b[0m', B:'\x1b[1m' };
const say  = (...a) => console.log(...a);
const head = t => say(`\n${C.B}${t}${C.x}\n${'─'.repeat(Math.min(72, t.length + 8))}`);
function fail(m) { console.error(`\n${C.r}✗ ${m}${C.x}\n`); process.exit(1); }

function have(bin) {
  const r = spawnSync(bin, ['-version'], { stdio: 'ignore' });
  if (r.error) { const r2 = spawnSync(bin, ['--version'], { stdio: 'ignore' }); return !r2.error; }
  return true;
}

function sh(bin, args, { quiet = false } = {}) {
  if (DRY) { say(`${C.d}$ ${bin} ${args.join(' ')}${C.x}`); return { code: 0, out: '' }; }
  const r = spawnSync(bin, args, { encoding: 'utf8', maxBuffer: 1 << 28 });
  if (r.status !== 0 && !quiet) {
    fail(`${bin} failed (exit ${r.status})\n${(r.stderr || '').slice(-1500)}`);
  }
  return { code: r.status, out: r.stdout || '', err: r.stderr || '' };
}

function shLive(bin, args) {
  if (DRY) { say(`${C.d}$ ${bin} ${args.join(' ')}${C.x}`); return Promise.resolve(0); }
  return new Promise((res, rej) => {
    const p = spawn(bin, args, { stdio: ['ignore', 'inherit', 'inherit'] });
    p.on('close', c => c === 0 ? res(0) : rej(new Error(`${bin} exit ${c}`)));
    p.on('error', rej);
  });
}

/* ------------------------------------------------------------------ probe */

function probe(file) {
  if (DRY) {
    return { width:2160, height:3840, fps:60, vfr:false, codec:'hevc', bitDepth:10,
      colorPrimaries:'bt2020', colorTransfer:'arib-std-b67', colorMatrix:'bt2020nc',
      colorRange:'limited', hasDolbyVisionRPU:true, dvProfile:8.4, hasHdr10Metadata:false,
      durationSec:13.3, bitrateMbps:107.3, sizeMB:170.6, audioCodec:'aac', moovAtEnd:true,
      hdr:true, hdrFormat:'dolbyvision' };
  }
  const { out } = sh('ffprobe', ['-v','quiet','-print_format','json',
    '-show_streams','-show_format','-show_entries','stream_side_data', file]);
  const j = JSON.parse(out);
  const v = j.streams.find(s => s.codec_type === 'video') || {};
  const a = j.streams.find(s => s.codec_type === 'audio') || {};
  const rate = s => { const [n,d] = (s||'0/1').split('/').map(Number); return d ? n/d : 0; };
  const sd = JSON.stringify(v.side_data_list || []);

  return {
    width: v.width, height: v.height,
    fps: +rate(v.avg_frame_rate).toFixed(3),
    vfr: Math.abs(rate(v.r_frame_rate) - rate(v.avg_frame_rate)) > 0.02,
    codec: v.codec_name, bitDepth: v.bits_per_raw_sample ? +v.bits_per_raw_sample : 8,
    colorPrimaries: v.color_primaries, colorTransfer: v.color_transfer,
    colorMatrix: v.color_space, colorRange: v.color_range || 'limited',
    hasDolbyVisionRPU: /dovi|DOVI|Dolby/i.test(sd) || /dvh|dvhe/.test(v.codec_tag_string || ''),
    dvProfile: (sd.match(/"dv_profile":\s*(\d+)/) || [])[1] ? +(sd.match(/"dv_profile":\s*(\d+)/)[1]) : null,
    hasHdr10Metadata: /Mastering display|Content light/i.test(sd),
    durationSec: +(j.format.duration || 0),
    bitrateMbps: +(((+j.format.bit_rate || 0) / 1e6).toFixed(1)),
    sizeMB: +(((+j.format.size || 0) / 1048576).toFixed(1)),
    audioCodec: a.codec_name || null,
    moovAtEnd: false,
  };
}

/** The engine keys off src.hdr / src.hdrFormat — derive them from the tags. */
function deriveHdr(s) {
  const tr = (s.colorTransfer || '').toLowerCase();
  const pri = (s.colorPrimaries || '').toLowerCase();
  s.hdr = tr === 'smpte2084' || tr === 'arib-std-b67' || pri.includes('2020') || !!s.hasDolbyVisionRPU;
  s.hdrFormat = s.hasDolbyVisionRPU ? 'dolbyvision'
    : tr === 'smpte2084' ? (s.hasHdr10Metadata ? 'hdr10' : 'pq')
    : tr === 'arib-std-b67' ? 'hlg' : null;
  return s;
}

/* ------------------------------------------------------------------- main */

(async () => {
  head('Vague CLI');

  // toolchain
  const tools = { ffmpeg: have('ffmpeg'), ffprobe: have('ffprobe'), dovi_tool: have('dovi_tool') };
  say(`  ffmpeg    ${tools.ffmpeg ? C.g+'found' : C.r+'MISSING'}${C.x}`);
  say(`  ffprobe   ${tools.ffprobe ? C.g+'found' : C.r+'MISSING'}${C.x}`);
  say(`  dovi_tool ${tools.dovi_tool ? C.g+'found' : C.y+'not found (Dolby Vision will be lost)'}${C.x}`);
  if (!DRY && (!tools.ffmpeg || !tools.ffprobe)) fail('Install ffmpeg first — see cli/SETUP.md');

  head('Source');
  const src = deriveHdr(probe(input));
  say(`  ${src.width}×${src.height} @ ${src.fps}fps ${src.vfr ? C.y+'VFR'+C.x : 'CFR'} · ` +
      `${src.codec} ${src.bitDepth}-bit · ${src.bitrateMbps} Mbps · ${src.durationSec}s`);
  say(`  colour  ${src.colorPrimaries}/${src.colorTransfer}/${src.colorMatrix}`);
  say(`  dolby   ${src.hasDolbyVisionRPU ? C.g+`RPU present (profile ${src.dvProfile ?? '8.4'})`+C.x : 'none'}`);

  const dx = diagnose(src);
  if (dx.criticalCount) {
    head('Problems found');
    for (const f of dx.findings) {
      if (f.severity === 'ok') continue;
      const col = f.severity === 'critical' ? C.r : C.y;
      say(`  ${col}[${f.severity}]${C.x} ${f.title}`);
      say(`     ${C.d}${f.symptom}${C.x}`);
    }
    const t = identifyToolchain(src);
    if (t) say(`  ${C.b}→ likely source: ${t.likely}${C.x}`);
  }

  // ---- lossless remux path -------------------------------------------------
  if (REMUX) {
    head('Lossless remux');
    const args = ['-hide_banner','-y','-i',input,'-c','copy','-movflags','+faststart'];
    if (PATCH) { args.push('-metadata','duration=0'); }
    args.push(outPath);
    await shLive('ffmpeg', args);
    if (PATCH && !DRY) zeroDurations(outPath);
    say(`\n${C.g}✓ ${outPath}${C.x}  (streams copied — no quality change)`);
    return;
  }

  // ---- plan ---------------------------------------------------------------
  const p = plan({ ...src, path: input, outPath }, platform, {
    uploadPath: 'web',
    preconditioning: !src.hdr,           // never denoise/sharpen an HDR master
  });
  const o = p.output;

  if (KEEP4K) { o.width = src.width; o.height = src.height; }
  const wantHdr = o.hdr && !FORCE_SDR;

  head('Plan');
  say(`  ${src.width}×${src.height} → ${C.B}${o.width}×${o.height}${C.x} @ ${C.B}${o.fps}fps CFR${C.x}`);
  say(`  ${wantHdr ? C.g + 'HDR preserved (' + (o.hdrTarget || 'hlg') + ')' + C.x : 'SDR (BT.2390 tonemap)'}`);
  say(`  ${o.codec} · ${o.targetMbps} Mbps · est ${o.estimatedSizeMB} MB`);
  say(`  ${C.d}${p.decisions.fps.reason}${C.x}`);

  const dvUsable = src.dvProfile == null || [8, 8.4, 5].includes(Number(src.dvProfile));
  const isDV = wantHdr && src.hasDolbyVisionRPU && tools.dovi_tool && dvUsable;
  if (wantHdr && src.hasDolbyVisionRPU && tools.dovi_tool && !dvUsable)
    say(`  ${C.y}⚠ Dolby Vision profile ${src.dvProfile} is not a social profile — encoding as plain HDR.${C.x}`);
  const route = isDV ? 'Dolby Vision (RPU carry)' : wantHdr ? 'HDR (HLG/PQ)' : 'SDR';
  say(`\n  route: ${C.B}${route}${C.x}`);

  if (wantHdr && src.hasDolbyVisionRPU && !tools.dovi_tool) {
    say(`  ${C.y}⚠ dovi_tool missing — Dolby Vision metadata will be dropped.${C.x}`);
    say(`  ${C.y}  The HLG base layer survives, so you keep HDR, just not DV.${C.x}`);
  }

  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'vague-'));
  try {
    if (isDV)        await encodeDV(input, outPath, src, o, tmp);
    else if (wantHdr) await encodeHDR(input, outPath, src, o);
    else              await encodeSDR(input, outPath, p, o);

    head('Verify');
    if (DRY) { say('  (dry run — nothing encoded)'); return; }
    const res = probe(outPath);
    const ok = (l, c, extra='') => say(`  ${c ? C.g+'✓' : C.r+'✗'}${C.x} ${l}${extra}`);
    ok(`resolution ${res.width}×${res.height}`, res.width === o.width && res.height === o.height);
    ok(`frame rate ${res.fps} fps`, Math.abs(res.fps - o.fps) < 0.5);
    ok(`codec ${res.codec} ${res.bitDepth}-bit`, true);
    ok(`transfer ${res.colorTransfer}`, true);
    if (isDV) {
      const dv = sh('dovi_tool', ['info','-i',outPath,'-f','0'], { quiet:true });
      const kept = /profile[^\d]*8/i.test(dv.out);
      ok('Dolby Vision RPU survived', kept);
      if (!kept) fail('Dolby Vision was lost during encoding — output not trustworthy.');
    }
    if (PATCH) { zeroDurations(outPath); say(`  ${C.y}⚑ header duration zeroed (players will show 0:00)${C.x}`); }

    const mb = (fs.statSync(outPath).size / 1048576).toFixed(1);
    say(`\n${C.g}${C.B}✓ Done — ${outPath} (${mb} MB)${C.x}`);
    say(`${C.d}  Upload this from TikTok Studio on desktop. Do not edit it afterwards.${C.x}\n`);
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }
})().catch(e => fail(e.message));

/* --------------------------------------------------------------- encoders */

async function encodeDV(input, out, src, o, tmp) {
  const rpu = path.join(tmp, 'rpu.bin');
  head('1/3 Extracting Dolby Vision RPU');
  if (!DRY) {
    const ff = spawn('ffmpeg', ['-v','error','-i',input,'-c:v','copy',
      '-bsf:v','hevc_mp4toannexb','-f','hevc','-']);
    const dv = spawn('dovi_tool', ['extract-rpu','-','-o',rpu]);
    ff.stdout.pipe(dv.stdin);
    await new Promise((res, rej) => { dv.on('close', c => c === 0 ? res() : rej(new Error('RPU extract failed'))); dv.on('error', rej); });
    const st = fs.statSync(rpu);
    say(`  ${C.g}✓${C.x} ${(st.size/1024).toFixed(0)} KB of RPU metadata`);
  } else say(`  ${C.d}$ ffmpeg ... | dovi_tool extract-rpu - -o ${rpu}${C.x}`);

  head('2/3 Encoding base layer (x265, RPU re-injected)');
  const x265 = [
    'hdr-opt=1','repeat-headers=1',
    'colorprim=bt2020',
    `transfer=${src.colorTransfer === 'arib-std-b67' ? 'arib-std-b67' : 'smpte2084'}`,
    'colormatrix=bt2020nc',
    `dolby-vision-rpu=${rpu}`,'dolby-vision-profile=8.4',
    `vbv-maxrate=${Math.round(o.targetMbps*1500)}`,
    `vbv-bufsize=${Math.round(o.targetMbps*3000)}`,
  ].join(':');

  await shLive('ffmpeg', ['-hide_banner','-y','-i',input,
    '-vf',`scale=${o.width}:${o.height}:flags=lanczos,format=yuv420p10le`,
    '-r',String(o.fps),'-fps_mode','cfr',
    '-c:v','libx265','-preset','slow','-crf','18','-x265-params',x265,
    '-c:a','aac','-b:a','256k','-ar','48000','-ac','2',
    '-tag:v','hvc1','-movflags','+faststart', out]);
  head('3/3 Verifying');
}

async function encodeHDR(input, out, src, o) {
  head('Encoding (HDR preserved)');
  const hlg = src.colorTransfer === 'arib-std-b67';
  await shLive('ffmpeg', ['-hide_banner','-y','-i',input,
    '-vf',`scale=${o.width}:${o.height}:flags=lanczos,format=yuv420p10le`,
    '-r',String(o.fps),'-fps_mode','cfr',
    '-c:v','libx265','-preset','slow','-crf','18','-profile:v','main10',
    '-x265-params',`hdr-opt=1:repeat-headers=1:colorprim=bt2020:transfer=${hlg?'arib-std-b67':'smpte2084'}:colormatrix=bt2020nc`,
    '-colorspace','bt2020nc','-color_primaries','bt2020',
    '-color_trc', hlg ? 'arib-std-b67' : 'smpte2084',
    '-c:a','aac','-b:a','256k','-ar','48000','-ac','2',
    '-tag:v','hvc1','-movflags','+faststart', out]);
}

async function encodeSDR(input, out, p, o) {
  head('Encoding (SDR)');
  const i = p.ffmpeg.indexOf('-vf');
  const vf = i >= 0 ? p.ffmpeg[i+1] : `scale=${o.width}:${o.height}:flags=lanczos,format=yuv420p`;
  await shLive('ffmpeg', ['-hide_banner','-y','-i',input,
    '-vf', vf, '-r',String(o.fps),'-fps_mode','cfr',
    '-c:v','libx264','-preset','slow','-crf','17',
    '-maxrate',`${Math.round(o.targetMbps*1.5)}M`,'-bufsize',`${o.targetMbps*3}M`,
    '-profile:v','high','-level','4.2',
    '-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709',
    '-c:a','aac','-b:a','256k','-ar','48000','-ac','2',
    '-movflags','+faststart', out]);
}

/* ----------------------------------------------- the duration-zero patch */

function zeroDurations(file) {
  const buf = fs.readFileSync(file);
  let n = 0;
  const walk = (start, end) => {
    let o = start;
    while (o + 8 <= end) {
      let size = buf.readUInt32BE(o);
      const type = buf.toString('latin1', o + 4, o + 8);
      let hdr = 8;
      if (size === 1) { size = Number(buf.readBigUInt64BE(o + 8)); hdr = 16; }
      else if (size === 0) size = end - o;
      if (size < hdr || o + size > end) break;
      const c = o + hdr, ver = buf.readUInt8(c);
      if (type === 'mvhd' || type === 'mdhd') {
        if (ver === 1) buf.writeBigUInt64BE(0n, c + 24); else buf.writeUInt32BE(0, c + 16);
        n++;
      } else if (type === 'tkhd') {
        if (ver === 1) buf.writeBigUInt64BE(0n, c + 28); else buf.writeUInt32BE(0, c + 20);
        n++;
      } else if (['moov','trak','mdia','edts'].includes(type)) walk(c, o + size);
      o += size;
    }
  };
  walk(0, buf.length);
  fs.writeFileSync(file, buf);
  return n;
}
